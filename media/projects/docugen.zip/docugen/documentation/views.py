from django.views.generic import TemplateView
from django.views.generic.detail import DetailView
from django.shortcuts import get_object_or_404
from .models import Project, Documentation
from .forms import SearchForm
from .parsers import CodeParser
from .generators import DocumentationGenerator
from django.http import FileResponse, HttpResponse
from django.views.generic.edit import FormView
from rest_framework import viewsets
from .models import Project
from .serializers import ProjectSerializer
from django.views.generic import ListView, CreateView, TemplateView


class HomeView(TemplateView):
    template_name = 'documentation/home.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['projects'] = Project.objects.all()
        
        if Project.objects.exists():
            context['project'] = Project.objects.first()
            
        return context
    '''
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['projects'] = Project.objects.all()
        context['recent_docs'] = Documentation.objects.order_by('-generated_at')[:5]
    ''' 
        # Add the first project as default (or remove export buttons from home page)
       


class ProjectDetailView(DetailView):
    model = Project
    template_name = 'documentation/projects_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['documentations'] = self.object.documentation_set.order_by('-generated_at')
        context['project'] = self.object  # Make sure project is available
        return context
    
class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

class GenerateDocsView(TemplateView):
    template_name = 'documentation/generate.html'
    
    def get(self, request, *args, **kwargs):
        project = get_object_or_404(Project, pk=self.kwargs['project_id'])
        parser = CodeParser()
        generator = DocumentationGenerator()
        
        # Parse the directory (assuming `base_directory` contains the project files)
        parsed_data = parser.parse_directory(project.base_directory)
        
        # Generate documentation content in the desired format (e.g., HTML)
        documentation_content = generator.generate(parsed_data, 'html')
        
        # Save the generated documentation to the database
        documentation = Documentation.objects.create(
            project=project,
            format='html',
            content=documentation_content,
            metadata={'structure': parsed_data}
        )
        
        # Pass context to the template to render the generated documentation
        context = {
            'project': project,
            'documentation': documentation_content
        }
        
        return self.render_to_response(context)

class ExportDocumentationView(TemplateView):
    def get(self, request, *args, **kwargs):
        project = get_object_or_404(Project, pk=self.kwargs['project_id'])
        format_type = self.kwargs['format']
        
        # Get the latest documentation or generate a new one if it doesn't exist
        documentation = Documentation.objects.filter(
            project=project,
            format=format_type
        ).order_by('-generated_at').first()
        
        if not documentation:
            # If documentation is not found, generate new documentation
            parser = CodeParser()
            generator = DocumentationGenerator()
            parsed_data = parser.parse_directory(project.base_directory)
            content = generator.generate(parsed_data, format_type)
            
            # Save the newly generated documentation
            documentation = Documentation.objects.create(
                project=project,
                format=format_type,
                content=content,
                metadata={'structure': parsed_data}
            )
        
        # Return the appropriate response based on the requested format
        if format_type == 'pdf':
            return self._serve_pdf(documentation)
        else:
            return self._serve_text(documentation)
    
    def _serve_pdf(self, documentation):
        # Assuming the content is a file path to the PDF
        return FileResponse(open(documentation.content, 'rb'), content_type='application/pdf')
    
    def _serve_text(self, documentation):
        # Return content as plain text (or whatever format is appropriate)
        return HttpResponse(documentation.content, content_type='text/plain')

class SearchView(FormView):
    template_name = 'documentation/search.html'
    form_class = SearchForm
    
    def form_valid(self, form):
        query = form.cleaned_data['query']
        # Implement your search logic here
        results = []  # This would be replaced with actual search results
        return self.render_to_response(self.get_context_data(form=form, results=results))

class ProjectListView(ListView):
    model = Project
    template_name = 'documentation/projects_detail.html'

class ProjectCreateView(CreateView):
    model = Project
    fields = ['name', 'base_directory']
    template_name = 'documentation/project_create.html'
    success_url = '/projects/'

class RecentDocsView(ListView):
    model = Documentation
    template_name = 'documentation/recent_docs.html'
    queryset = Documentation.objects.order_by('-generated_at')[:10]

class PDFExportsView(ListView):
    model = Documentation
    template_name = 'documentation/pdf_exports.html'
    queryset = Documentation.objects.filter(format='pdf')
    
class MarkdownView(TemplateView):
    template_name = 'documentation/markdown.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add markdown-specific context here
        context['markdown_docs'] = Documentation.objects.filter(format='md')
        return context

class AIAssistantView(TemplateView):
    template_name = 'documentation/ai_assistant.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add AI assistant context here
        return context

class SettingsView(TemplateView):
    template_name = 'documentation/settings.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add settings context here
        return context