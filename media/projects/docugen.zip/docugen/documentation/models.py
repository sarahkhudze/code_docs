from django.db import models

class Project(models.Model):
    name = models.CharField(max_length=255)
    base_directory = models.CharField(max_length=512)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name

class Documentation(models.Model):
    FORMAT_CHOICES = [
        ('md', 'Markdown'),
        ('html', 'HTML'),
        ('pdf', 'PDF')
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    format = models.CharField(max_length=10, choices=FORMAT_CHOICES)
    content = models.TextField(blank=True)
    generated_at = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict)  # Updated to use the standard models.JSONField
    
    class Meta:
        ordering = ['-generated_at']
    
    def __str__(self):
        return f"{self.project.name} - {self.get_format_display()}"
