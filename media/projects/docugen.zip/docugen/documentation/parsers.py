import ast
from pathlib import Path
import os

class CodeParser:
    def __init__(self):
        self.ignore_dirs = {'__pycache__', '.git', 'venv'}
        self.ignore_files = {'__init__.py'}
    
    def parse_file(self, file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            tree = ast.parse(f.read())
        
        components = {
            'file_path': file_path,
            'classes': [],
            'functions': [],
            'docstring': ast.get_docstring(tree) or ''
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_info = {
                    'name': node.name,
                    'docstring': ast.get_docstring(node) or '',
                    'methods': []
                }
                for item in node.body:
                    if isinstance(item, ast.FunctionDef):
                        method_info = {
                            'name': item.name,
                            'docstring': ast.get_docstring(item) or '',
                            'args': self._parse_arguments(item.args)
                        }
                        class_info['methods'].append(method_info)
                components['classes'].append(class_info)
            
            elif isinstance(node, ast.FunctionDef):
                function_info = {
                    'name': node.name,
                    'docstring': ast.get_docstring(node) or '',
                    'args': self._parse_arguments(node.args)
                }
                components['functions'].append(function_info)
        
        return components
    
    def _parse_arguments(self, arguments):
        args = []
        for arg in arguments.args:
            args.append({
                'name': arg.arg,
                'type': ast.unparse(arg.annotation) if arg.annotation else 'Any',
                'default': None
            })
        
        for i, default in enumerate(arguments.defaults, start=len(arguments.args)-len(arguments.defaults)):
            if i < len(args):
                args[i]['default'] = ast.unparse(default)
        
        if arguments.vararg:
            args.append({
                'name': f'*{arguments.vararg.arg}',
                'type': 'Any',
                'default': None
            })
        if arguments.kwarg:
            args.append({
                'name': f'**{arguments.kwarg.arg}',
                'type': 'Any',
                'default': None
            })
        
        return args
    
    def parse_directory(self, root_dir):
        documentation = []
        root_path = Path(root_dir)
        
        for file_path in root_path.rglob('*.py'):
            if any(part in self.ignore_dirs for part in file_path.parts):
                continue
            if file_path.name in self.ignore_files:
                continue
                
            try:
                parsed = self.parse_file(str(file_path))
                documentation.append(parsed)
            except Exception as e:
                print(f"Error parsing {file_path}: {e}")
        
        return documentation