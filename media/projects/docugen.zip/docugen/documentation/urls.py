from django.urls import path
from django.contrib import admin
from . import views
from documentation.views import (
    HomeView,
    ProjectDetailView,
    GenerateDocsView,
    ExportDocumentationView,
    SearchView
)

urlpatterns = [
    # ... your existing URLs ...
    path('admin/', admin.site.urls),
    path('home/', HomeView.as_view(), name='home'),
    path('', views.HomeView.as_view(), name='home_root'),
    #path('projects/<int:pk>/', ProjectDetailView.as_view(), name='projects_detail'),
    #path('projects/<int:pk>/', views.ProjectDetailView.as_view(), name='projects_detail'),
    #path('projects/<int:pk>/', views.ProjectDetailView.as_view(), name='projects_detail')
    # urls.py
    #path('projects/', ProjectListView.as_view(), name='projects_detail'),  # List view
    path('projects/<int:pk>/', ProjectDetailView.as_view(), name='projects_detail'),  # Detail view
    path('generate/<int:project_id>/', GenerateDocsView.as_view(), name='generate-docs'),
    path('export/<int:project_id>/<str:format>/', ExportDocumentationView.as_view(), name='export-docs'),
    path('search/', SearchView.as_view(), name='search'),
    path('projects/', views.ProjectListView.as_view(), name='project-list'),
    path('projects/new/', views.ProjectCreateView.as_view(), name='project-create'),
    path('docs/recent/', views.RecentDocsView.as_view(), name='recent-docs'),
    path('docs/pdf/', views.PDFExportsView.as_view(), name='pdf-exports'),
    path('docs/markdown/', views.MarkdownView.as_view(), name='markdown'),
    path('tools/ai-assistant/', views.AIAssistantView.as_view(), name='ai-assistant'),
    path('settings/', views.SettingsView.as_view(), name='settings'),
]