from django.template.loader import render_to_string
from django.conf import settings
import os
import markdown
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet

class DocumentationGenerator:
    def __init__(self):
        self.output_dir = os.path.join(settings.MEDIA_ROOT, 'docs')
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate(self, parsed_data, format):
        if format == 'md':
            return self._generate_markdown(parsed_data)
        elif format == 'html':
            return self._generate_html(parsed_data)
        elif format == 'pdf':
            return self._generate_pdf(parsed_data)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _generate_markdown(self, parsed_data):
        md_content = "# Project Documentation\n\n"
        
        for module in parsed_data:
            md_content += f"## File: {module['file_path']}\n"
            
            if module['docstring']:
                md_content += f"\n{module['docstring']}\n"
            
            for cls in module['classes']:
                md_content += f"\n### Class: {cls['name']}\n"
                if cls['docstring']:
                    md_content += f"\n{cls['docstring']}\n"
                
                for method in cls['methods']:
                    md_content += f"\n#### Method: {method['name']}\n"
                    md_content += f"**Arguments**:\n"
                    for arg in method['args']:
                        default = f" = {arg['default']}" if arg['default'] else ""
                        md_content += f"- {arg['name']}: {arg['type']}{default}\n"
        
        return md_content
    
    def _generate_html(self, parsed_data):
        context = {
            'modules': parsed_data,
            'title': 'Project Documentation'
        }
        return render_to_string('documentation/template.html', context)
    
    def _generate_pdf(self, parsed_data):
        output_path = os.path.join(self.output_dir, 'documentation.pdf')
        doc = SimpleDocTemplate(output_path, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        story.append(Paragraph("Project Documentation", styles['Title']))
        
        for module in parsed_data:
            story.append(Paragraph(f"File: {module['file_path']}", styles['Heading2']))
            
            if module['docstring']:
                story.append(Paragraph(module['docstring'], styles['Normal']))
            
            for cls in module['classes']:
                story.append(Paragraph(f"Class: {cls['name']}", styles['Heading3']))
                if cls['docstring']:
                    story.append(Paragraph(cls['docstring'], styles['Normal']))
                
                for method in cls['methods']:
                    story.append(Paragraph(f"Method: {method['name']}", styles['Heading4']))
                    args_text = "Arguments:\n" + "\n".join(
                        f"- {arg['name']}: {arg['type']}" + 
                        (f" = {arg['default']}" if arg['default'] else "")
                        for arg in method['args']
                    )
                    story.append(Paragraph(args_text, styles['Normal']))
        
        doc.build(story)
        return output_path