from django import forms
from django.db import models

class SearchForm(forms.Form):
    query = forms.CharField(
        label='Search documentation',
        widget=forms.TextInput(attrs={
            'placeholder': 'Search classes, functions...',
            'class': 'form-control'
        })
    )