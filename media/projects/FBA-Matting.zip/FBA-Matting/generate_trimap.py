import os
import torch
import numpy as np
from torchvision import transforms
import cv2
from tkinter import Tk, filedialog
from tkinter import messagebox

# Constants
IMG_EXT = ('.png', '.jpg', '.jpeg', '.JPG', '.JPEG')
CLASS_MAP = {
    "background": 0, "aeroplane": 1, "bicycle": 2, "bird": 3, "boat": 4, "bottle": 5, "bus": 6, "car": 7,
    "cat": 8, "chair": 9, "cow": 10, "diningtable": 11, "dog": 12, "horse": 13, "motorbike": 14, "person": 15,
    "potted plant": 16, "sheep": 17, "sofa": 18, "train": 19, "tv/monitor": 20
}

def trimap(probs, size, conf_threshold):
    """
    Creates a trimap based on a simple dilation algorithm.
    """
    mask = (probs > 0.05).astype(np.uint8) * 255
    pixels = 2 * size + 1
    kernel = np.ones((pixels, pixels), np.uint8)
    dilation = cv2.dilate(mask, kernel, iterations=1)
    remake = np.zeros_like(mask)
    remake[dilation == 255] = 127
    remake[probs > conf_threshold] = 255
    return remake

def browse_and_process_image(target_class, conf_threshold, output_dir):
    """
    Allows users to select an image file, processes it, and generates a trimap.
    """
    # Create a Tkinter root window and hide it
    root = Tk()
    root.withdraw()  # Don't need a full GUI, just the file dialog

    # Prompt user to select an image file
    filename = filedialog.askopenfilename(title="Select an image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.JPG;*.JPEG")])
    
    if not filename:
        messagebox.showerror("Error", "No file selected. Exiting.")
        return

    # Load and preprocess the image
    original_image = cv2.imread(filename)
    if original_image is None:
        messagebox.showerror("Error", f"Could not load image {filename}")
        return

    input_image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    preprocess = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    input_tensor = preprocess(input_image_rgb)
    input_batch = input_tensor.unsqueeze(0)

    # Load the model
    model = torch.hub.load('pytorch/vision:v0.6.0', 'deeplabv3_resnet101', pretrained=True)
    model.eval()

    # Perform inference
    with torch.no_grad():
        output = model(input_batch)['out'][0]
        output = torch.softmax(output, 0)
    output_cat = output[CLASS_MAP[target_class], ...].numpy()

    # Generate and save trimap
    trimap_image = trimap(output_cat, 7, conf_threshold)
    os.makedirs(output_dir, exist_ok=True)
    trimap_filename = os.path.join(output_dir, os.path.basename(filename).split('.')[0] + '_trimap.png')
    cv2.imwrite(trimap_filename, trimap_image)

    # Display results
    cv2.imshow('Original Image', original_image)
    cv2.imshow('Trimap', trimap_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    messagebox.showinfo("Success", f"Trimap saved at: {trimap_filename}")

def select_output_directory():
    """
    Opens a dialog to select the output directory.
    """
    root = Tk()
    root.withdraw()  # Hide the main window
    output_dir = filedialog.askdirectory(title="Select Output Directory")
    return output_dir

def main():
    # Get target class and confidence threshold from the user
    target_class = input("Enter the target class (e.g., 'person', 'car', etc.): ")
    if target_class not in CLASS_MAP:
        print("Invalid class. Exiting.")
        return
    
    conf_threshold = float(input("Enter confidence threshold (0.5 to 1.0): "))
    if not (0.5 <= conf_threshold <= 1.0):
        print("Invalid confidence threshold. Exiting.")
        return
    
    # Ask for output directory
    output_dir = select_output_directory()
    if not output_dir:
        print("No output directory selected. Exiting.")
        return

    # Process the image
    browse_and_process_image(target_class, conf_threshold, output_dir)

if __name__ == "__main__":
    main()
