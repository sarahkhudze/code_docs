import tkinter as tk
from tkinter import filedialog, messagebox
import torch
import cv2
import os
import numpy as np
from torchvision import transforms

# Class mapping (you can customize this based on your use case)
CLASS_MAP = {
    'person': 15,
    'car': 3,
    'bird': 17,
    'dog': 18,
    # Add more classes as needed
}

# Function to generate the trimap
def trimap(prob_map, kernel_size=7, conf_threshold=0.5):
    """
    Generate a trimap from the probability map.
    """
    # Normalize prob_map to be between 0 and 1
    prob_map = np.clip(prob_map, 0, 1)

    # Debug: Check the range of the probability map
    print(f"Min probability: {np.min(prob_map)}, Max probability: {np.max(prob_map)}")

    # Create a binary map by thresholding the probability map
    binary_map = (prob_map > conf_threshold).astype(np.uint8) * 255  # Foreground

    # Debug: Show the binary map before further processing
    cv2.imshow('Binary Map', binary_map)
    cv2.waitKey(0)

    # Perform a morphological operation to generate the trimap
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    eroded = cv2.erode(binary_map, kernel, iterations=1)
    dilated = cv2.dilate(binary_map, kernel, iterations=1)

    # Combine eroded (background) and dilated (foreground) with the binary map to create the trimap
    trimap = np.zeros_like(binary_map)
    trimap[dilated == 255] = 255  # Foreground
    trimap[eroded == 255] = 128  # Unknown region
    return trimap

# Function to process image
def browse_and_process_image(target_class, conf_threshold, output_dir):
    """
    Allows users to upload an image, processes it, and generates a trimap.
    """
    # Open file dialog to select an image
    filepath = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if not filepath:
        messagebox.showerror("Error", "No image selected!")
        return

    if not filepath.endswith(('.png', '.jpg', '.jpeg')):
        messagebox.showerror("Error", f"{filepath} is not a supported image format.")
        return

    # Load and preprocess the image
    original_image = cv2.imread(filepath)
    if original_image is None:
        messagebox.showerror("Error", f"Could not load image {filepath}")
        return

    input_image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    preprocess = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    input_tensor = preprocess(input_image_rgb)
    input_batch = input_tensor.unsqueeze(0)

    # Load the model (use the correct weights for the model)
    model = torch.hub.load('pytorch/vision:v0.6.0', 'deeplabv3_resnet101', pretrained=True)
    model.eval()

    # Perform inference
    with torch.no_grad():
        output = model(input_batch)['out'][0]
        output = torch.softmax(output, 0)

    # Get the output for the specified class (target_class)
    output_cat = output[CLASS_MAP[target_class], ...].cpu().numpy()  # Make sure it's on the CPU

    # Debug: Show the output for the selected class
    cv2.imshow('Class Probability Map', output_cat)
    cv2.waitKey(0)

    # Generate and save trimap
    trimap_image = trimap(output_cat, 7, conf_threshold)
    os.makedirs(output_dir, exist_ok=True)
    trimap_filename = os.path.join(output_dir, os.path.basename(filepath).split('.')[0] + '_trimap.png')
    cv2.imwrite(trimap_filename, trimap_image)

    # Display results
    cv2.imshow('Original Image', original_image)
    cv2.imshow('Trimap', trimap_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    messagebox.showinfo("Success", f"Trimap saved at: {trimap_filename}")

# Tkinter GUI Setup
root = tk.Tk()
root.title("Image Processing")

# Class Selection (Dropdown)
class_label = tk.Label(root, text="Select Class:")
class_label.pack(padx=10, pady=5)
class_selector = tk.StringVar(value="person")
class_menu = tk.OptionMenu(root, class_selector, *CLASS_MAP.keys())
class_menu.pack(padx=10, pady=5)

# Confidence Slider
conf_label = tk.Label(root, text="Set Confidence Threshold:")
conf_label.pack(padx=10, pady=5)
conf_slider = tk.Scale(root, from_=0.5, to=1.0, resolution=0.01, orient=tk.HORIZONTAL)
conf_slider.set(0.95)
conf_slider.pack(padx=10, pady=5)

# Output Directory Input
output_dir_label = tk.Label(root, text="Output Directory:")
output_dir_label.pack(padx=10, pady=5)
output_dir_entry = tk.Entry(root)
output_dir_entry.insert(0, './output')
output_dir_entry.pack(padx=10, pady=5)

# Run Button
run_button = tk.Button(root, text="Run", command=lambda: browse_and_process_image(class_selector.get(), conf_slider.get(), output_dir_entry.get()))
run_button.pack(padx=10, pady=20)

# Start the Tkinter main loop
root.mainloop()
