from pymatting import cutout

cutout(
    # input image path
    "../data/lemur/lemur.png",
    # input trimap path
    "../data/lemur/lemur_trimap.png",
    # output cutout path
    "lemur_cutout.png",
)
