---
name: Feature request
about: Create a feature request to help us improve the PyMatting library.
title: "[FEATURE REQUEST \U0001F680]"
labels: ''
assignees: ''

---

**Feature description**

(Feature description here)
